N=int(input())

for i in range(N):


    x=list(map(int,input().split()))


    y = sorted(x)
    z = sorted(x,reverse=True)
    if i==0:
        print()
        print("Lumberjacks:")
        if x==y or x==z:


            print("Ordered")
        else:
            print("Unordered")
    else:
        if x == y or x==z:
            print("Ordered")
        else:
            print("Unordered")