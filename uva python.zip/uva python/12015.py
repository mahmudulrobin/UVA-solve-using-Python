

T=int(input())


for i in range(T):

    max=0
    for j in range(10):
        x,y=input().split(' ')





        if max<y[j]:
            max=y[j]