




n = int(input("enter the number of cases: "))

for i in range(n):
    x = list(map(int,input().split()))
    if x[1]>x[0] & x[1]<x[2]:
        print("case {}: {}".format(i+1,x[1]))

    else:
        break

