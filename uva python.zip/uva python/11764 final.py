

T=int(input())


for i in range(T):
    z = 0
    c = 0
    a = int(input())
    x=list(map(int,input().split()))

    for j in range(1,a):
        if x[j-1]<x[j]:
            z=z+1
        if x[j-1]>x[j]:
            c=c+1


    print("Case {}: {} {}".format(i+1,z,c))
