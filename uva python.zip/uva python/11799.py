

T=int(input())

for i in range(T):

    o=list(map(int,input().split()))

    o.sort()
    print("Case {}: {}".format(i+1,o[0]))